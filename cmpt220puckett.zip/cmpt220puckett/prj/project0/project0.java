 public class project0 { 
   public static void main(String[] args) { 
     // Display message Welcome to Java! on the console 
     System.out.println("Hello World!"); 
   } 
 }
